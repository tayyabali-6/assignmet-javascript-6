let days = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday']

setInterval(function datTime() {
    document.getElementById('dat-time').innerHTML = new Date()
},1000)


getNameOfToday = () => {
    let now = new Date()
    let today = now.getDay()
    document.getElementById('Result').innerHTML = days[today]
}

dob = () => {
   let dob = document.getElementById('dob').value 
  if (!dob) {
    return alert('Please Enter your birthday')
  }

   let now = new Date()
   let dat = new Date(dob)
   let days = now-dat
   let birthday = days / (1000 * 60 * 60 * 24) 
   document.getElementById('Result').innerHTML = Math.floor(birthday)

}

nextBirthday = () => {
  
    let dob = document.getElementById('dob').value 
    if (!dob) {
      return alert('Please Enter your next birthday')
    }
  
     let now = new Date()
     let dat = new Date(dob)
     let days = dat-now
     let birthday = days / (1000 * 60 * 60 * 24) 
     document.getElementById('Result').innerHTML = Math.floor(birthday)
  
}

greetUser = () => {
   let Result = document.getElementById('Result')
  let now = new Date()
  let hours = now.getHours()
  
  if (hours > 1 && hours < 10) {
    Result.innerHTML = 'Good Morning'
}else if (hours > 10 && hours < 17) {
      Result.innerHTML = 'Good Afternone'    
  }else if (hours > 17&& hours <= 24) {
      Result.innerHTML = 'Good Nigt'    
  }

} 

function time1() {
    let now = new Date()
    let sec = now.getSeconds()
    let hours = now.getHours()
    let min = now.getMinutes()
      document.getElementById('Result').innerHTML += '<br>' + hours + ': ' + min +': '+ sec
}

time2 = () => {
  time1()  
}
time3 = () => {
  time1()  
}
